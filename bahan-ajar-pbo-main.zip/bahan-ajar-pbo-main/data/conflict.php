<?php

// buat namespace data\satu 
// dengan class conflict
// class sample
// class dummy

// buat namespace data\dua
// dengan class conflict
