<?php

// import data/person.php
require_once "data/Person.php";

// buat 2 object new peson dengan parameter yang berbeda
$alzah = new Person("alzah", "bengkulu");
$fariski = new Person("fariski", "jambi");

// tambahkan echo "Program Selesai" . PHP_EOL;
echo "Program Selesai" . PHP_EOL;
