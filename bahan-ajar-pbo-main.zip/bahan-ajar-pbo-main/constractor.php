<?php

// import data/person.php
require_once "data/Person.php";

// buat object new person dengan 2 parameter
$alzah = new Person("alzah", "bengkulu");

// vardump object
var_dump($alzah);
