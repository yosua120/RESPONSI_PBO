<?php

// buat namespace
// import data dari conflict
// buat obeject dari namespace yang di buat

// import data helper
// tampilkan helper menggunakan echo
// masukan Helper\helpMe();
